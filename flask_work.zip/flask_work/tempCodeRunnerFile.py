 # eid = eid
    # aid = aid
    # q = 'select update_status_appointment(%s, %s)'
    # mycursor.execute(q, (aid, 0))
    # ans = mycursor.fetchall()
    # mydb.commit()