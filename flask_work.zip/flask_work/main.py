from flask import Flask, render_template, request, redirect, session, url_for
import mysql.connector
import json

mydb = mysql.connector.connect(
   host='127.0.0.1',
    port = '3306',
  user="root",
  password="root",
  database="vehicle"
)
mycursor = mydb.cursor()


app = Flask(__name__)
app.secret_key = 'BAD_SECRET_KEY'

@app.route('/', methods=['GET', 'POST'])
def index():
    q = 'select * from vehicle v inner join vehicle_branch vb on v.vehicle_id = vb.vehicle_id;'
    if request.method == "POST":
        details = request.form
        carname = details['carname']
        branch = details['branch']
        print(carname, branch)
        if(carname!='' and (branch=='' or branch == 'Choose...')):
            q = "select * from vehicle v inner join vehicle_branch vb on v.vehicle_id = vb.vehicle_id having vehicle_name like '%"+carname+"%';"
        if(carname=='' and (branch!='' and branch != 'Choose...')):
            q = "select * from vehicle v inner join vehicle_branch vb on v.vehicle_id = vb.vehicle_id having branch_id="+branch+";"
        if(carname!=''and (branch!='' and branch != 'Choose...')):
            q = "select * from vehicle v inner join vehicle_branch vb on v.vehicle_id = vb.vehicle_id having branch_id="+branch+" and vehicle_name like '%"+carname+"%';"

    print(q)
    mycursor.execute(q)
    data = mycursor.fetchall()

    return render_template('landingPage.html', data = data, len = len(data))

@app.route('/add', methods=['GET', 'POST'])
def add_user():
    
    if request.method == "POST":
        details = request.form
        firstName = details['fname']
        lastName = details['lname']
    
        q = "INSERT INTO temp(fname, lname) VALUES (%s, %s)"
        val = (firstName, lastName)
        mycursor.execute(q, val)
        mydb.commit()

        return redirect('/')

    return render_template('addUser.html')

@app.route('/vehicle/<vid>', methods=['GET', 'POST'])
def vehicle_details(vid):
    id = vid
    q = 'select * from vehicle v inner join vehicle_branch vb on v.vehicle_id = vb.vehicle_id having v.vehicle_id ='+id+";"
    review_query = 'SELECT r.review, c.first_name, r.rating FROM reviews r inner join customers c on r.customer_id = c.id where vehicle_id ='+ vid +";"
    mycursor.execute(q)
    data = mycursor.fetchall()

    mycursor.execute(review_query)
    reviews = mycursor.fetchall()
    return render_template('ind_vehicle.html', data = data[0], available = data[0][9], reviews = reviews, isCust = True)

@app.route('/buy/<vid>', methods=['GET', 'POST'])
def vehicle_buy(vid):
    id = vid
    q = 'select * from vehicle v inner join vehicle_branch vb on v.vehicle_id = vb.vehicle_id having v.vehicle_id ='+id+";"
    mycursor.execute(q)
    data = mycursor.fetchall()
    print(data)
    bid = data[0][7]
    if request.method == "POST":
        d = request.form
        q = 'INSERT INTO sales (vehicle_id, customer_id, employee_id, selling_price, branch_id) VALUES (%s, %s, %s, %s, %s);'
        val = (id, d['userId'], d['empId'], d['sellP'], bid)
        try:
            mycursor.execute(q, val)
            mydb.commit()
            return render_template('sales_form.html', data = data[0], succ = "Succesfull Puchased.")
        except:
            return render_template('sales_form.html', data = data[0], flash = "Please enter valid details.")        
    return render_template('sales_form.html', data = data[0])

@app.route('/clogin', methods=['GET', 'POST'])
def user_signup():
    return render_template('user_signup.html')


@app.route('/elogin', methods=['GET', 'POST'])
def employee_login():
    err_msg = ""
    if request.method == "POST":
        d = request.form
        q = 'select * from employee where emp_id = '+d['emp_id']+";"
        mycursor.execute(q)
        data = mycursor.fetchall()
        if(len(data)==0):
            err_msg = "Please enter valid details"
        else:
            return redirect('/elanding/'+d['emp_id'])
        # if(d['']=='manager@gmail.com' and d['password']=='1234'):
        #     return render_template("employee_landingPage.html", data = data, len = len(data))
    return render_template('employee_login.html', err_msg = err_msg)

@app.route('/elanding/<eid>', methods=['GET', 'POST'])
def employee_landing(eid):
    id = eid
    q = 'select * from employee where emp_id = '+ id +";"
    mycursor.execute(q)
    data1 = mycursor.fetchall()
    bid = data1[0][4]
    isManager = data1[0][2]!='worker'
    q1 = "SELECT * FROM vehicle v inner join vehicle_branch vb on vb.vehicle_id = v.vehicle_id having vb.branch_id = "+str(bid)+";"
    mycursor.execute(q1)
    data = mycursor.fetchall()
    return render_template("employee_landingPage.html", data = data, len = len(data), isManager = isManager, emp_id = id)

@app.route('/vehicle/edit/<eid>/<vid>', methods=['GET', 'POST'])
def edit_details_vehicle(vid, eid):
    id = vid
    eid = eid

    q = 'select * from vehicle v inner join vehicle_branch vb on v.vehicle_id = vb.vehicle_id having v.vehicle_id ='+id+";"
    review_query = 'SELECT r.review, c.first_name, r.rating, r.review_id FROM reviews r inner join customers c on r.customer_id = c.id where vehicle_id ='+ id +";"

    mycursor.execute(q)
    data = mycursor.fetchall()

    q = 'select * from employee where emp_id = '+ eid +";"
    mycursor.execute(q)
    data1 = mycursor.fetchall()
    print(data1)
    isManager = data1[0][2]!='worker'

    mycursor.execute(review_query)
    reviews = mycursor.fetchall()

    return render_template('ind_vehicle.html', data = data[0], available = data[0][9], eid = eid, reviews = reviews, isCust = False, isManager = isManager)

@app.route('/vehicle/update/<eid>/<vid>', methods=['GET', 'POST'])
def delete_details_vehicle(eid, vid):
    vid = vid
    eid = eid
    succ = ""
    err = ""
    val = None
    q1 = 'select * from vehicle where vehicle_id = '+str(vid)+";"
    mycursor.execute(q1)
    vehicle_details = mycursor.fetchall()

    mycursor.execute('select getBranchId(%s)',(eid,))
    bid = mycursor.fetchall()
    mycursor.execute('select countVehicles(%s, %s)',(vid, bid[0][0]))
    veh_count = mycursor.fetchall()[0][0]
    
    if request.method == "POST":
        q = 'UPDATE vehicle SET vehicle_model = %s, price = %s WHERE (vehicle_id = %s);'
        d = request.form
        val = (d['vehicle_model'], d['price'], vid)
        try:
            mycursor.execute(q, val)
            mydb.commit()
            q = 'call update_vehicle_count(%s, %s, %s)'
            mycursor.execute(q, (vid, bid[0][0], d['vehicle_count']))
            return redirect("/elanding/"+eid)
        except:
            return render_template("update_details.html", vehicle_details = vehicle_details, eid = eid, err = err)
        print(succ, err)
    return render_template("update_details.html", vehicle_details = vehicle_details, eid = eid, succ = succ, val = veh_count)

@app.route('/reservations', methods=['GET', 'POST'])
def reservations_user():
    succ = ""
    if(request.method == "POST"):
        print("Entered")
        d = request.form
        print(d)
        succ = "Appointment created sucessfully"
        q = "call create_reservation(%s, %s, %s);"
        mycursor.execute(q, (d['time'], d['customer_id'], d['branch']))
        mydb.commit()
    return render_template('reservations_user.html', succ = succ)

@app.route('/update/<eid>', methods = ['GET', 'POST'])
def update_details_emp(eid):
    eid = eid
    mycursor.execute('select * from employee where emp_id = %s',(eid,))
    data = mycursor.fetchall()
    if request.method == "POST":
        d = request.form
        val = (d['emp_name'], d['emp_add'].strip(), d['emp_number'], eid)
        try:
            q = 'update employee set emp_name = %s, emp_add = %s, emp_number = %s where emp_id = %s'
            mycursor.execute(q, val)
            mydb.commit()
            return(redirect('/elanding/'+eid))
        except:
            return(render_template('updateemp.html', d = data[0]))
    return render_template('updateemp.html', d = data[0])


@app.route('/appointments/<eid>', methods=['GET', 'POST'])
def pending_appointments(eid):
    eid = eid
    mycursor.execute('select getBranchId(%s)',(eid,))
    bid = mycursor.fetchall()
    app_query = 'select * from reservations where reservation_status = %s and branch_id = %s'
    mycursor.execute(app_query, ("Pending", bid[0][0]))
    pending_appointments = mycursor.fetchall()
    return render_template('pending_appointments.html', pending_appointments = pending_appointments, emp_id = bid[0][0], eid = eid)

@app.route('/approve/<eid>/<aid>', methods=['GET', 'POST'])
def approve_pending_appointments(eid, aid):
    eid = eid
    aid = aid
    q = 'select update_status_appointment(%s, %s)'
    mycursor.execute(q, (aid, 1))
    ans = mycursor.fetchall()
    mydb.commit()
    return redirect('/appointments/'+eid)

@app.route('/reject/<eid>/<aid>', methods=['GET', 'POST'])
def reject_pending_appointments(eid, aid):
    eid = eid
    aid = aid
    q = 'select update_status_appointment(%s, %s)'
    mycursor.execute(q, (aid, 0))
    ans = mycursor.fetchall()
    mydb.commit()
    return redirect('/appointments/'+eid)

# @app.route('/delete/comment/<cid>', methods=['GET', 'POST'])
# def delete_comment(cid):
#     cid = cid
    # aid = aid
    # q = 'select update_status_appointment(%s, %s)'
    # mycursor.execute(q, (aid, 0))
    # ans = mycursor.fetchall()
    # mydb.commit()
    # return redirect('/vehicle/'+cid)

if __name__ == '__main__': 
    app.debug = True
    app.run()